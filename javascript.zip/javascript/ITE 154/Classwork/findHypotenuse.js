function findHypotenuse( side1, side2 ){
	
	var sidec = Math.sqrt( Math.pow(side1, 2) + Math.pow (side2, 2) );
	return sidec;	
	
}