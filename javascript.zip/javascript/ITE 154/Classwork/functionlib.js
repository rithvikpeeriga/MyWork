function calcAvg ( num1, num2 ) {

	var avg = (num1 + num2 ) / 2;
	
	return avg;
	
}


function findMax( num1, num2 ) {
	
	if( num1 > num2 ) {
		
		return num1;
	}
	else {
		
		return num2;
	}
	
}

function changePic( filename, idname ) {
	
	var url = "http://newton.ncc.edu/gansonj/ite154/img/" + filename;

	document.getElementById(idname).src = url;
	
}