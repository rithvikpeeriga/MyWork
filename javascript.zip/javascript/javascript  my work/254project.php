
>
<html>
<head>
<title></title>
 
<style type="text/css">
 

 
#contentwrap {
background: #F4F5E7;
border: 8px #FF9E01 solid;
padding: 20px;
width: 600px;
margin: 20px auto 0px auto;
border-radius: 25px;
text-align: center;
}
 
#heading {
font-size: 1.5em;
border-bottom: 6px #484452 double;
padding: 10px 0px 10px 0px;
}
 
.formtext {
text-align: center;
margin-top: 20px;
}
 
 
</style>
 
</head>
<body background="http://i67.tinypic.com/5f41si.jpg">
 
<div id="contentwrap">
 
<div id="heading">
Apex Music Store
</div>
 
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
 
<div class="formtext">Enter your first name</div>
<div><input type="text" name="fname"></div>
 
<div class="formtext">Enter your last name</div>
<div><input type="text" name="lname"></div>
 
<div class="formtext">Enter your Shipping address</div>
<div><input type="text" name="shipping"></div>
 
 <div class ="formtext">Select Music type</div>
<div>
<select name="musictype">
<option value="a">90's Melody's Collection price= 50$</option>
<option value="b">Hip-Hop Collection price = 70$</option>
<option value="c">Electronic Music Collection price = 80$</option>
<option value="d">Rap Music Collection price = 50$</option>
<option value="e">2017 Hits Collection price = 100$ </option>           
</select>
</div>
  <div style="margin-top: 12px;">Select Shipping type</div>
<div><input type="radio" name="shippingtype">Standard Shipping 10$ (5-7 business days)</div>
<div><input type="radio" name="shippingtype1">Express Shipping 20$ (2-3 business days)</div>
 
 
<div style="margin-top:10px;">
<input type="submit" value="Order to confirm">
</div>
 
</form>
 
<?php
 
 $totalprice;
 $shippingprice;
if( isset( $_POST['fname'] ) && isset ($_POST['lname'] ) && isset ($_POST['musictype'])) {
 
 $price = $_POST['musictype'];
 
 if ($price == "a"){
	 $musicprice = 50;
 }
 else if ($price =="b") {
 $musicprice= 70;}
 else if ($price=="c") {
 $musicprice = 80;}
 else if ($price =="d") {
 $musicprice=50;}	 
 else {
	 $musicprice=100;
 }
 if (isset ($_POST['shippingtype'])){
	 $shippingprice=10; 
 }
 else if (isset($_POST['shippingtype1'])){
	 $shippingprice=20;
 }
 $totalprice = ($musicprice + $shippingprice);
 
 echo "<div>First name: ".$_POST['fname']."</div>\n";
 echo "<div>Last name: ".$_POST['lname']."</div>\n";
 echo "<div>Shipping Address: ".$_POST['shipping']."</div>\n";
 echo "<div>Total Price: ".$totalprice."</div>\n";
 echo "<div> Congratulations, your music is on the way!</div>\n";
} // ends if  
 
 
?>
 
 
</div> <!-- ends div#contentwrap -->
 
</body>
</html>
 
 