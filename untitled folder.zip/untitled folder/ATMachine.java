import javax.swing.*;
public class ATMachine {

	public static void main(String[] args) {
		
		// get initial account info and create object
		String acct = JOptionPane.showInputDialog( "Enter acct number" );
		String startbal = JOptionPane.showInputDialog( "Enter starting balance" );
		 
		BankAccount myacct = new BankAccount( acct, new Money( startbal ) );
		 
		String menuchoice = showMenu();
		 
		while( menuchoice.equals("q") == false ) {
		 
		// handle menu option
		if( menuchoice.equals( "d" ) ) {
		 
		String dep = JOptionPane.showInputDialog("Enter deposit amt");
		myacct.deposit( new Money( dep ) );
		JOptionPane.showMessageDialog( null, "Deposit success!!!\n" + myacct );
		 
		} // ends deposit code
		else if( menuchoice.equals( "w" ) ) {
		 
		String wdrl = JOptionPane.showInputDialog("Enter withdrawal amt");
		if( myacct.withdraw( new Money( wdrl ) ) == true ) {
		 
		JOptionPane.showMessageDialog( null, "Withdraw success!!!\n" + myacct );
		}
		else {
		 
		JOptionPane.showMessageDialog( null, "Insufficient Funds!!\n" + myacct );
		}
		 
		} // ends withdraw code
		else {
		 
		JOptionPane.showMessageDialog( null, myacct );
		}
		 
		menuchoice = showMenu();
		 
		} // ends while loop
		
		
		
		
		
		
		
		
		
		
		

	}

	private static String showMenu() {
		
		String menumsg = "Select an option\n\n";
		menumsg += "(d)eposit\n";
		menumsg += "(w)ithrawal\n";
		menumsg += "(v)iew balance\n";
		menumsg += "(q)uit\n\n";
		 
		return JOptionPane.showInputDialog( menumsg );
		 
		
		
		
	}

}
