
public class BankAccount {

	private String acctnum;
	private Money balance;
	 
	public BankAccount( String a, Money b ) {
	 
	this.acctnum = a;
	this.balance = b;
	}
	 
	public BankAccount() {
	 
	this.acctnum = "00000";
	this.balance = new Money();
	}
	 
	// getter methods
	public String getAcctNum() {
	 
	return this.acctnum;
	}
	 
	public Money getBalance() {
	 
	return this.balance;
	}
	 
	// instance methods
	public void deposit( Money depamt ) {
	 
	this.balance = this.balance.addMoney( depamt );
	}
	 
	 
	public boolean withdraw( Money withamt ) {
	 
	if( this.balance.compareMoney( withamt ) >= 0 ) {
	 
	this.balance = this.balance.subtractMoney( withamt );
	return true;
	 
	}
	else {
	 
	return false;
	}
	}
	 
	public String toString() {
	 
	return "Acct number " + this.acctnum + " has a balance of " + this.balance;
	 
	}
	 
	
	
	
	
	
	
	
	
	
	
	
}
